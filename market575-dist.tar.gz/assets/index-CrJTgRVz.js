const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Vo2A3L3d.js","assets/index-DyuSBjwb.js","assets/index-EQ8juSWk.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-DyuSBjwb.js";const _=p("App",{web:()=>r(()=>import("./web-Vo2A3L3d.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
