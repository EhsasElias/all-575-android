const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CQOVqlEa.js","assets/index-Cd4iPvQx.js","assets/index-DcCrUj4t.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-Cd4iPvQx.js";const _=p("App",{web:()=>r(()=>import("./web-CQOVqlEa.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
